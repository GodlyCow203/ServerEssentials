package serveressentials.serveressentials.economy;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class ShopGUIListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        ShopGUIManager.handleClick(event);
    }
}
