package serveressentials.serveressentials.economy;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import serveressentials.serveressentials.ServerEssentials;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class EconomyMessagesManager {

    private static File file;
    private static FileConfiguration config;
    private static final Map<String, String> messages = new HashMap<>();
    private static final MiniMessage miniMessage = MiniMessage.miniMessage();
    private static ServerEssentials plugin;

    /**
     * Initialize the manager with the plugin instance.
     * Must be called once in onEnable().
     */
    public static void setup(ServerEssentials pl) {
        plugin = pl;

        File folder = new File(plugin.getDataFolder(), "messages");
        if (!folder.exists()) folder.mkdirs();

        file = new File(folder, "Economy.yml");
        if (!file.exists()) {
            plugin.saveResource("messages/Economy.yml", false);
        }

        config = YamlConfiguration.loadConfiguration(file);
        loadMessages();
    }

    /**
     * Load all messages from the config into memory.
     */
    private static void loadMessages() {
        messages.clear(); // Clear old messages to reload fresh
        for (String key : config.getKeys(true)) {
            if (config.isString(key)) {
                messages.put(key, config.getString(key));
            }
        }
    }

    /**
     * Reload the Economy.yml file from disk and refresh all messages.
     */
    public static void reload() {
        if (plugin == null) {
            Bukkit.getLogger().severe("[ServerEssentials] EconomyMessagesManager not initialized! Call setup(plugin) first.");
            return;
        }

        if (!file.exists()) {
            if (!file.getParentFile().exists()) file.getParentFile().mkdirs();
            plugin.saveResource("messages/Economy.yml", false);
        }

        // Load a fresh copy from disk
        config = YamlConfiguration.loadConfiguration(file);

        // Reload messages map
        loadMessages();

        Bukkit.getLogger().info("[ServerEssentials] EconomyMessagesManager reloaded successfully.");
    }

    /**
     * Get a message by key and replace placeholders.
     */
    public static Component getMessage(String key, Map<String, String> placeholders) {
        String raw = messages.getOrDefault(key, "<red>Missing message: " + key);
        if (placeholders != null) {
            for (Map.Entry<String, String> entry : placeholders.entrySet()) {
                raw = raw.replace("%" + entry.getKey() + "%", entry.getValue());
            }
        }
        return miniMessage.deserialize(raw);
    }

    public static Component getMessage(String key) {
        return getMessage(key, null);
    }

    /**
     * Save the current config to disk
     */
    public static void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
