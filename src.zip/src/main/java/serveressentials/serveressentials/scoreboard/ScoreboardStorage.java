package serveressentials.serveressentials.scoreboard;


import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class ScoreboardStorage {

    private final File file;
    private YamlConfiguration config;

    public ScoreboardStorage(JavaPlugin plugin) {
        this.file = new File(plugin.getDataFolder(), "storage/scoreboard.yml");
        reload();
    }

    public void reload() {
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) { e.printStackTrace(); }
        }
        config = YamlConfiguration.loadConfiguration(file);
    }

    public boolean togglePlayer(Player player) {
        String path = "players." + player.getUniqueId() + ".enabled";
        boolean state = !config.getBoolean(path, true);
        config.set(path, state);
        save();
        return state;
    }

    public boolean isEnabled(Player player) {
        return config.getBoolean("players." + player.getUniqueId() + ".enabled", true);
    }

    public void setPlayerLayout(Player player, String layout) {
        config.set("players." + player.getUniqueId() + ".layout", layout);
        save();
    }

    public String getPlayerLayout(Player player) {
        return config.getString("players." + player.getUniqueId() + ".layout", "default");
    }

    private void save() {
        try { config.save(file); } catch (IOException e) { e.printStackTrace(); }
    }
}
