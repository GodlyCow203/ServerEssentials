package serveressentials.serveressentials.homes;


// Main homes GUI holder
public class HomesMainHolder implements org.bukkit.inventory.InventoryHolder {
    @Override
    public org.bukkit.inventory.Inventory getInventory() { return null; }
}

