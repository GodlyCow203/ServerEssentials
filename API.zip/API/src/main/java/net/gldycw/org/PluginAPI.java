package net.gldycw.org;


import net.gldycw.org.home.HomeAPI;
import net.gldycw.org.shop.ShopAPI;

public interface PluginAPI {
    ShopAPI getShopAPI();
    HomeAPI getHomeAPI();
    String getVersion();
    boolean isEnabled();
}