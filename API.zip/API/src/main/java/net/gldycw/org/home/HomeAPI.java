package net.gldycw.org.home;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;


public interface HomeAPI {
    CompletableFuture<Boolean> setHome(Player player, int slot, String name, Location location);
    CompletableFuture<Optional<Home>> getHome(Player player, int slot);
    CompletableFuture<Map<Integer, Home>> getAllHomes(Player player);
    CompletableFuture<Boolean> removeHome(Player player, int slot);
}